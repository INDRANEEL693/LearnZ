import React from "react";

function Contact() {
  return (
    <div style={styles.container}>
      <h2>Contact Us</h2>
      <p>Email: info@core-next.com</p>
      <p>Phone: +91 9876543210</p>
      <p>Address: Bangalore, India</p>
    </div>
  );
}

const styles = { container: { padding: "4rem 2rem", textAlign: "center" } };

export default Contact;
