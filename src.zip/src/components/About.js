import React from "react";

function About() {
  return (
    <div style={styles.container}>
      <h2>About Core-Next</h2>
      <p>
        Core-Next is a software company dedicated to providing high-quality
        internship opportunities. We focus on skill development, live projects,
        and real-world experience.
      </p>
    </div>
  );
}

const styles = {
  container: {
    padding: "4rem 2rem",
    textAlign: "center",
  },
};

export default About;
